﻿using FlowerBouquetManagementSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace FlowerBouquetManagementSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public DbSet<Registration>? Registrations { get; set; }
        public DbSet<Customer>? Customers { get; set; }
        public DbSet<Bouquet>? Bouquets { get; set; }
        public DbSet<Order>? Orders { get; set; }
        public DbSet<Payment>? Payments { get; set; }
        public DbSet<OrderBouquet>? OrderBouquets { get; set; }
        

        public DbSet<Users1> Users1 { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Registration>()
        .HasOne(r => r.Customer)
        .WithOne(c => c.Registration)
        .HasForeignKey<Customer>(c => c.RegistrationId);

            modelBuilder.Entity<Customer>()
                .HasMany(c => c.Orders)
                .WithOne(o => o.Customer)
                .HasForeignKey(o => o.CustomerId);

            modelBuilder.Entity<OrderBouquet>()
                .HasKey(ob => new { ob.OrderId, ob.BouquetId });

            modelBuilder.Entity<OrderBouquet>()
                .HasOne(ob => ob.Order)
                .WithMany(o => o.OrderBouquets)
                .HasForeignKey(ob => ob.OrderId);

            modelBuilder.Entity<OrderBouquet>()
                .HasOne(ob => ob.Bouquet)
                .WithMany(b => b.OrderBouquets)
                .HasForeignKey(ob => ob.BouquetId);

            modelBuilder.Entity<Order>()
                .HasOne(o => o.Payment)
                .WithMany(p => p.Orders)
                .HasForeignKey(o => o.PaymentId);

            modelBuilder.Entity<Bouquet>()
                .Property(b => b.Price)
                .HasColumnType("decimal(18, 2)");

            modelBuilder.Entity<Payment>()
                .Property(p => p.Amount)
                .HasColumnType("decimal(18, 2)");
            modelBuilder.Entity<Users1>().HasNoKey();

        }

    }

}