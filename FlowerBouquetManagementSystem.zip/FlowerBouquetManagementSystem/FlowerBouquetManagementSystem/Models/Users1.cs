﻿using System.ComponentModel.DataAnnotations;

namespace FlowerBouquetManagementSystem.Models
{
    public class Users1
    {
        [Key]
        public int Id { get; set; } // Primary key

        [Required]
        public string? UserName { get; set; }

        [Required]
        public string? Email { get; set; }

        [Required]
        public string? Password { get; set; }
    }
}
