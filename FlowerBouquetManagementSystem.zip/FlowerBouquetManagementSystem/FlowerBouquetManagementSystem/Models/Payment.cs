﻿namespace FlowerBouquetManagementSystem.Models
{
    public class Payment
    {
        public int Id { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; }

        // Relationship with Order
        public ICollection<Order>? Orders { get; set; }
    }
}
