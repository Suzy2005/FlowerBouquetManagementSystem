﻿namespace FlowerBouquetManagementSystem.Models
{
    public class Bouquet
    {
        public int Id { get; set; }
    public string? Name { get; set; }
    public decimal Price { get; set; }

    // Relationship with Orders
    public ICollection<OrderBouquet>? OrderBouquets { get; set; }
    }
}
