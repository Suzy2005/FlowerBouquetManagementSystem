﻿namespace FlowerBouquetManagementSystem.Models
{
    public class OrderBouquet
    {
        public int OrderId { get; set; }
        public Order? Order { get; set; }

        public int BouquetId { get; set; }
        public Bouquet? Bouquet { get; set; }
    }
}
