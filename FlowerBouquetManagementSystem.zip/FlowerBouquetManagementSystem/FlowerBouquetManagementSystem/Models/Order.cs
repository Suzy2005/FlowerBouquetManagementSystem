﻿namespace FlowerBouquetManagementSystem.Models
{
    public class Order
    {
        public int Id { get; set; }
        public DateTime OrderDate { get; set; }

        // Foreign Key to Customer
        public int CustomerId { get; set; }
        public Customer? Customer { get; set; }

        // Relationship with Bouquets
        public ICollection<OrderBouquet>? OrderBouquets { get; set; }

        // Foreign Key to Payment
        public int PaymentId { get; set; }
        public Payment? Payment { get; set; }
    }
}
