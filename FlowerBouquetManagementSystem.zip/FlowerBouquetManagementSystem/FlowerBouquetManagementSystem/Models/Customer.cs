﻿namespace FlowerBouquetManagementSystem.Models
{
    public class Customer
    {
        public int Id { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Phone { get; set; }

        // Relationship with Orders
        public ICollection<Order>? Orders { get; set; }

        // Foreign Key to Registration
        public int RegistrationId { get; set; }
        public Registration? Registration { get; set; }
    }
}
