﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FlowerBouquetManagementSystem.Migrations
{
    /// <inheritdoc />
    public partial class m480 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "Users",
                newName: "User");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "User",
                newName: "Users");
        }
    }
}
