﻿using FlowerBouquetManagementSystem.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace FlowerBouquetManagementSystem.Controllers
{
    public class LoginController : Controller
    {
        private readonly ApplicationDbContext _context;

        public LoginController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ViewData["ErrorMessage"] = "Username and password are required.";
                return View();
            }

            var user = await _context.Users1
                .FirstOrDefaultAsync(u => u.UserName == username && u.Password == password);

            if (user != null)
            {
                // Simulate setting session or authentication
                TempData["Message"] = $"Welcome, {user.UserName}!";
                return RedirectToAction("Index", "Home");
            }

            ViewData["ErrorMessage"] = "Invalid username or password.";
            return View();
        }


        // Other methods (Index, Details, Create, Edit, Delete) remain unchanged
    }
}
