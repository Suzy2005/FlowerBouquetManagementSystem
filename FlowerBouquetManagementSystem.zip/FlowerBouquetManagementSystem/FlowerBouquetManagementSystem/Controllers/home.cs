﻿using Microsoft.AspNetCore.Mvc;

namespace FlowerBouquetManagementSystem.Controllers
{
    public class home : Controller
    {
        public IActionResult home2()
        {

            return View();
        }
    }
}
